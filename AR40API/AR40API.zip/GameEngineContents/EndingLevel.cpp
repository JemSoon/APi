#include "EndingLevel.h"

EndingLevel::EndingLevel()
{

}

EndingLevel::~EndingLevel()
{

}

void EndingLevel::Loading()
{

}

void EndingLevel::Update()
{

}
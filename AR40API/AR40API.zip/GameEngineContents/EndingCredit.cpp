#include "EndingCredit.h"

EndingCredit::EndingCredit()
{

}

EndingCredit::~EndingCredit()
{

}


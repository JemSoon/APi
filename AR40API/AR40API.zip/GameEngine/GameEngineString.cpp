#include "GameEngineString.h"

GameEngineString::GameEngineString()
{

}

GameEngineString::~GameEngineString()
{

}


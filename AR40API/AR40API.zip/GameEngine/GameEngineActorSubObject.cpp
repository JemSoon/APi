#include "GameEngineActorSubObject.h"

GameEngineActorSubObject::GameEngineActorSubObject()
{

}

GameEngineActorSubObject::~GameEngineActorSubObject()
{

}


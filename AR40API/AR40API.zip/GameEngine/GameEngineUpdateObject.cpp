#include "GameEngineUpdateObject.h"

GameEngineUpdateObject::GameEngineUpdateObject()
{

}

GameEngineUpdateObject::~GameEngineUpdateObject()
{

}


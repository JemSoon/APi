#include "GameEngineNameObject.h"

GameEngineNameObject::GameEngineNameObject()
{

}

GameEngineNameObject::~GameEngineNameObject()
{

}

